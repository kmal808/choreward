import { Quest, Reward } from '../types';
import { Gift, Gamepad2, Film, Trophy, IceCream2 } from 'lucide-react';

export const mockQuests: Quest[] = [
  {
    id: '1',
    title: 'Clean Your Room',
    description: 'Make your bed, organize toys, and vacuum the floor',
    points: 50,
    difficulty: 'medium',
    category: 'chores',
    completed: false
  },
  {
    id: '2',
    title: 'Math Homework',
    description: 'Complete algebra worksheet pages 12-15',
    points: 75,
    difficulty: 'hard',
    category: 'homework',
    completed: false
  },
  {
    id: '3',
    title: 'Soccer Practice',
    description: 'Attend and participate in team practice',
    points: 60,
    difficulty: 'medium',
    category: 'sports',
    completed: false
  },
  {
    id: '4',
    title: 'Epic Spring Cleaning',
    description: 'Deep clean and organize your entire room including closet',
    points: 200,
    difficulty: 'epic',
    category: 'chores',
    completed: false
  }
];

export const mockRewards: Reward[] = [
  {
    id: '1',
    title: '1 Hour Gaming Time',
    description: 'Enjoy 60 minutes of video game time',
    pointsCost: 100,
    icon: Gamepad2.name,
    available: true
  },
  {
    id: '2',
    title: 'Movie Night',
    description: 'Pick a movie for family movie night',
    pointsCost: 150,
    icon: Film.name,
    available: true
  },
  {
    id: '3',
    title: '$10 Gift Card',
    description: 'Digital gift card for your favorite store',
    pointsCost: 500,
    icon: Gift.name,
    available: true
  },
  {
    id: '4',
    title: 'Ice Cream Party',
    description: 'Ice cream sundae party with friends',
    pointsCost: 300,
    icon: IceCream2.name,
    available: true
  },
  {
    id: '5',
    title: 'Special Achievement',
    description: 'Unlock when you complete 10 epic quests',
    pointsCost: 1000,
    icon: Trophy.name,
    available: false
  }
];