import React from 'react';
import { useState } from 'react';
import { UserProgress } from './components/UserProgress';
import { QuestCard } from './components/QuestCard';
import { RewardCard } from './components/RewardCard';
import { mockQuests, mockRewards } from './data/mockData';
import { Quest, User } from './types';
import { Sword, Gift } from 'lucide-react';

const initialUser: User = {
  id: '1',
  name: 'Kaius',
  points: 275,
  level: 1,
  completedQuests: 5,
  redeemedRewards: []
};

function App() {
  const [user, setUser] = useState<User>(initialUser);
  const [quests, setQuests] = useState<Quest[]>(mockQuests);
  const [activeTab, setActiveTab] = useState<'quests' | 'rewards'>('quests');

  const handleCompleteQuest = (questId: string) => {
    setQuests(prevQuests =>
      prevQuests.map(quest =>
        quest.id === questId
          ? { ...quest, completed: true, completedAt: new Date() }
          : quest
      )
    );

    const completedQuest = quests.find(q => q.id === questId);
    if (completedQuest && !completedQuest.completed) {
      setUser(prevUser => ({
        ...prevUser,
        points: prevUser.points + completedQuest.points,
        completedQuests: prevUser.completedQuests + 1,
        level: Math.floor((prevUser.points + completedQuest.points) / 1000)
      }));
    }
  };

  const handleRedeemReward = (rewardId: string) => {
    const reward = mockRewards.find(r => r.id === rewardId);
    if (reward && reward.available && user.points >= reward.pointsCost) {
      setUser(prevUser => ({
        ...prevUser,
        points: prevUser.points - reward.pointsCost,
        redeemedRewards: [...prevUser.redeemedRewards, rewardId]
      }));
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-4xl mx-auto p-6 space-y-6">
        <UserProgress user={user} />

        <div className="bg-white rounded-lg p-4 shadow-md">
          <div className="flex space-x-4 mb-6">
            <button
              onClick={() => setActiveTab('quests')}
              className={`flex items-center px-4 py-2 rounded-full ${
                activeTab === 'quests'
                  ? 'bg-indigo-500 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Sword className="w-5 h-5 mr-2" />
              Quests
            </button>
            <button
              onClick={() => setActiveTab('rewards')}
              className={`flex items-center px-4 py-2 rounded-full ${
                activeTab === 'rewards'
                  ? 'bg-indigo-500 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}
            >
              <Gift className="w-5 h-5 mr-2" />
              Rewards
            </button>
          </div>

          <div className="space-y-4">
            {activeTab === 'quests' ? (
              quests.map(quest => (
                <QuestCard
                  key={quest.id}
                  quest={quest}
                  onComplete={handleCompleteQuest}
                />
              ))
            ) : (
              mockRewards.map(reward => (
                <RewardCard
                  key={reward.id}
                  reward={reward}
                  userPoints={user.points}
                  onRedeem={handleRedeemReward}
                />
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;
